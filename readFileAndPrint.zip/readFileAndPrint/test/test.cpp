// test.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <STDLIB.H>
int main(int argc, char* argv[])
{
	FILE * fileIn = fopen("input.txt","r");
	if(fileIn==NULL){
		printf("Can not open file\n");
		exit(-1);
	}
	char buf[512]={0};
	int count=0;
	while(fgets(buf,512,fileIn)){
		printf("%d %s\n",++count,buf);
	}
	fclose(fileIn);
	printf("Hello World!\n");
	return 0;
}

